package com.onemonth.todolist;

/**
 * Created by alfredhanssen on 1/23/16.
 */
public class Constants
{
    public static final int ADD_ITEM_REQUEST_CODE = 1;

    public static final String ADD_ITEM_RESULT_KEY = "add_item_result";
}
