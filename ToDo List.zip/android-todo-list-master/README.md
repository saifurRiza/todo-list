# android-todo-list

A simple ToDo list app used as teaching material for the [One Month Android course](https://onemonth.com/courses). 

*Note:* The architectural concepts depicted here are simplified to be:

1. Accessible to the beginner    
2. Provide a solid foundation on which to build/scale, and     
3. To accommodate 3-4 hours of video "lecture" content.     
